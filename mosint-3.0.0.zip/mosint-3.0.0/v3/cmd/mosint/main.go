/*
Copyright © 2023 github.com/alpkeskin
*/
package main

import "github.com/alpkeskin/mosint/v3/pkg/engine"

func main() {
	engine.Start()
}
